<!-- jQuery -->
<script src="includes/js/jquery.min.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="includes/js/bootstrap.min.js"></script>
<!-- SweetAlert -->
<script src="includes/sweetalert-master/dist/sweetalert-dev.js"></script>